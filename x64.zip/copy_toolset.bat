copy /Y "C:\Users\Merlyn\Desktop\NWR6V2\Toolset.props" "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\MSBuild\Microsoft\VC\v180\Platforms\x64\PlatformToolsets\WindowsKernelModeDriver10.0\Toolset.props"
echo Done!
pause